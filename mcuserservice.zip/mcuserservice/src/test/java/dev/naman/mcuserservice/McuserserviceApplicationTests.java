package dev.naman.mcuserservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class McuserserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
