package dev.naman.mcuserservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class McuserserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(McuserserviceApplication.class, args);
	}

}
